
import { useEffect, useState } from 'react';
import axios from 'axios';

axios.defaults.baseURL = 'http://127.0.0.1:8000';
const token = localStorage.getItem('token');
if (token) axios.defaults.headers.common['Authorization'] = `Token ${token}`;

function App() {
  const [notes, setNotes] = useState([]);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const fetchNotes = async () => {
    const res = await axios.get('/api/notes/');
    setNotes(res.data);
  };

  const createNote = async () => {
    await axios.post('/api/notes/', { title, content });
    setTitle('');
    setContent('');
    fetchNotes();
  };

  const deleteNote = async (id) => {
    await axios.delete(`/api/notes/${id}/`);
    fetchNotes();
  };

  useEffect(() => {
    fetchNotes();
  }, []);

  return (
    <div className="max-w-xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Notes</h1>
      <input className="w-full border p-2 mb-2" placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} />
      <textarea className="w-full border p-2 mb-2" placeholder="Content" value={content} onChange={e => setContent(e.target.value)} />
      <button className="bg-blue-600 text-white px-4 py-2 rounded" onClick={createNote}>Add Note</button>
      <ul className="mt-4">
        {notes.map(note => (
          <li key={note.id} className="border p-2 my-2 rounded">
            <h2 className="font-semibold">{note.title}</h2>
            <p>{note.content}</p>
            <button onClick={() => deleteNote(note.id)} className="text-red-500 mt-1">Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
export default App;
